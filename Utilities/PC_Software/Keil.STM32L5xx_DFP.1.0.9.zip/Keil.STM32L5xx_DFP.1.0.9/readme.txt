/******************** (C) COPYRIGHT 2019 STMicroelectronics *******************************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Version            : V1.0.9
* Date               : 29/08/2019
* Description        : This file describes how to add STM32L5xx devices  support on MDK-ARM
*******************************************************************************************

Running the "Keil.STM32L5xx_DFP.1.0.9.pack" adds the following:
  
1. Part numbers for  :
- Legacy devices with 512kB Flash: STM32L552xExx/STM32L562xExx
- Legacy devices with 512kB Flash and �SMPS�: STM32L552xExxQ/STM32L562xExxQ


2. Automatic STM32L5 flash algorithm selection

3. SVD file for STM32L5x2


How to use:
==========
* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
or later installed. 
You can download pack from keil web site @ www.keil.com
 
* Double Clic on  "Keil.STM32L5xx_DFP.1.0.9.pack" in order to install this pack in 
the Keil install directory.


******************* (C) COPYRIGHT 2019 STMicroelectronics *****END OF FILE***************





	



