/******************** (C) COPYRIGHT 2019 STMicroelectronics **************************************
* File Name          : readme.txt
* Author             : STMicroelectronics
* Version            : V11.2
* Date               : 29/11/2019
* Description        : This file describes how to add STM32L5xx devices support on EWARM 
**************************************************************************************************

These packages contains the needed files to be installed in order to support STM32L5xx 
devices by EWARM8 and laters.

1. If you have already installed an STM32L5 patch before, you can remove it by running 
Uninstall_Patch.bat (run as administrator).

2. Running the "EWARMv8_STM32L5xx_Support_V11.2.exe" adds the following:  
 - Part numbers for  :
   Legacy devices with 512kB Flash: STM32L552ZE/STM32L562QE

 - Automatic STM32L5 flash algorithm selection

 - SVD file 


How to use:
==========
* Before installing the files mentioned above, you need to have EWARM v8.xx 
or later installed. 
You can download EWARM from IAR web site @ www.iar.com
 
* Run "EWARMv8_STM32L5xx_Support_V11.2.exe"  at EWARM install directory.
EWARM Install Directory is set by default to "C:\Program Files\IAR Systems\Embedded Workbench \", 
please change it manually if you have EWARM installed at different location.

******************* (C) COPYRIGHT 2019 STMicroelectronics *****END OF FILE************************





	



